package trabalhoTCPsocket;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

public class TCPCliente {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Socket S = null;
		try {
			 
	            
			Socket cliente = new Socket ("localhost",6789);
			
			DataOutputStream streamSaida= 
					new DataOutputStream(cliente.getOutputStream());
			streamSaida.writeUTF("Sistema Distribuido");
			streamSaida.flush();
			streamSaida.close();
			cliente.close();
			
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			 System.out.println("Servidor desconhecido: " + e.getMessage());
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
